$(document).ready(function() {
	/*$(".product_link").mouseenter(function() {
    /$('{{food.id}}').addClass('animated infinite shake');
}); 

$(".mbtn").mouseleave(function() {
    $(this).removeClass('animated pause');

  });*/
});